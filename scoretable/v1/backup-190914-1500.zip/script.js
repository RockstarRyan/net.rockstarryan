
// Nav buttons & hide/show screens on page load
document.getElementById('nb-home').style.color = "#07a";

function changeScreen(screenName, buttonName) {
    // Hide all screens
    var screens = document.getElementsByClassName('screen');
    for (var i = 0; i < screens.length; i++) {
        screens[i].style.display = 'none';
    }
    // Show corresponding screen
    document.getElementById(screenName).style.display = "block";

    // Used to: Show certain scoretables on game screens
    // Instead: create tables on load)

    // Make all buttons the default color
    var buttons = document.getElementsByClassName('nav-button');
    for (var j = 0; j < buttons.length; j++) {
        buttons[j].style.color = '#09e';
    }
    // Add special color to active "link"
    document.getElementById(buttonName).style.color = "#07a";
}
createGYNTable(); createFCTable();

// ************** GET YOUR NEIGHBOR ***********************************************************************
var numGYNPlayers;
// Create GYN score table
function createGYNTable() {
    numGYNPlayers = parseInt(document.getElementById("gyn-numplayers").value);
    var numRows = parseInt(document.getElementById("gyn-numrounds").value) + 2;
    var gyntable = document.getElementById("gyn-scoretable");
    gyntable.className = "scoretable";
    var errorMessage = document.getElementById("em-gyntable");

    if (numGYNPlayers>0 && numRows>1) {
        gyntable.style.display = "block";
        gyntable.style.maxHeight = String((52*numRows)+2).concat("px");
        errorMessage.style.display = "none";

        // Deletes all prexisting rows
        gyntable.innerHTML = "";

        // Determines width of columns
        var tableWidth = window.innerWidth - 30;
        var otherColumnsWidth = tableWidth - 100 - (0*numGYNPlayers);
        //var colwidth = String(otherColumnsWidth/numColumns).concat("px");
        var colwidth = String(100/numGYNPlayers).concat("%");
        var otherColumnsWidth = String(otherColumnsWidth).concat("px");

        // Creates first column
        var currentColumn = document.createElement("SECTION");
        currentColumn.className = "st-firstcolumn";
        for (var rn = 0; rn < numRows; rn++) {
            var currentCell = document.createElement("SECTION");
            currentCell.className = "st-cell";

            if (rn == 0) { // FIRST ROW only
                currentCell.className = "st-cell st-firstrow";
                currentCell.innerHTML = "Round";
            } else if (rn == (numRows-1)) { // LAST ROW only
                currentCell.className = "st-cell st-lastrow";
                currentCell.innerHTML = "Total";
            } else { // OTHER ROWS (round numbers)
                currentCell.innerHTML = rn;
            }
            // IMPORTANT: Adds cell to end of column
            currentColumn.appendChild(currentCell);
        }
        gyntable.appendChild(currentColumn);


        // Creates other rows
        var otherColumns = document.createElement("SECTION");
        otherColumns.className = "st-othercolumns";
        otherColumns.style.width = otherColumnsWidth;

        for (var rn = 0; rn < numRows; rn++) {
            // Creates a row, gives it class st-row
            var currentRow = document.createElement("SECTION");
            currentRow.className = "st-row";

            // Creates row content
            if (rn == 0) {                    // FIRST ROW only
                for (var cn = 1; cn <= numGYNPlayers; cn++) {
                    var currentCell = document.createElement("SECTION");
                    currentCell.className = "st-cell st-firstrow";
                    currentCell.style.width = colwidth;

                    if (cn == (numGYNPlayers)) {
                        currentCell.className = "st-cell st-firstrow st-lastcolumn";
                    }

                    currentCell.innerHTML = "<input class='st-playername' type='text' placeholder='Player ".concat(cn,"'>");

                    // IMPORTANT: Adds cell to end of row
                    currentRow.appendChild(currentCell);
                }
            } else if (rn == (numRows-1)) {   // LAST ROW only
                for (var cn = 1; cn <= numGYNPlayers; cn++) {
                    var currentCell = document.createElement("SECTION");
                    currentCell.className = "st-cell st-lastrow gyn-playertotal";
                    currentCell.style.width = colwidth;

                    currentCell.id = "gyn-pt-".concat(cn);

                    if (cn == (numGYNPlayers)) {
                        currentCell.className = "st-cell st-lastrow gyn-playertotal st-lastcolumn";}

                    // IMPORTANT: Adds cell to end of row
                    currentRow.appendChild(currentCell);
                }
            } else {                          // Other rows (round rows)
                for (var cn = 1; cn <= numGYNPlayers; cn++) {
                    var currentCell = document.createElement("SECTION");
                    currentCell.className = "st-cell";
                    currentCell.style.width = colwidth;

                    // Dealer Cell
                    if (cn-1==(rn-1)%numGYNPlayers) {
                        currentCell.className = "st-cell st-dealercell";
                    }
                    currentCell.innerHTML = "<input class='st-scorein gyn-round".concat(rn," gyn-player",cn,"' type='text' placeholder='0' id='gyn-cell-p",cn,"r",rn,"' onchange='calculateGYNPlayerTotals()'>");

                    // IMPORTANT: Adds cell to end of column
                    currentRow.appendChild(currentCell);
                }

                // NEXT STEPS: Add player columns. TO-DO:
                //    - Add editable player names
                //    - Add total row
                //    - Maybe: checkbox for team scores?
                //    - Highlight dealer cells
                // FOR PLAYER SUMS/SCORE ENTRIES - make an input box in each entry spot with class such as "score-p1" (using cn) and use fancy "getElementsByClassName" to add up the sum of all the inputs. Use calculate function as basis

                //    - FIX COLUMN WIDTH!!! otherColumnsWidth

            }
            // IMPORTANT: Adds column to scoretable
            otherColumns.appendChild(currentRow);
        }
        gyntable.appendChild(otherColumns);
        calculateGYNPlayerTotals();

    } else {
        gyntable.style.display = "none";
        errorMessage.style.display = "block";
    }
}

// Calculate GYN player totals
function calculateGYNPlayerTotals() {
    for (var cn = 1; cn < (numGYNPlayers+1); cn++) {
        var playerRoundTotals = document.getElementsByClassName("gyn-player".concat(cn));
        var playerTotal = 0;
        for (var m = 0; m < playerRoundTotals.length; m++) {
            if (playerRoundTotals[m].value != 0) {playerTotal = playerTotal + parseInt(playerRoundTotals[m].value);}
        }
        document.getElementById("gyn-pt-".concat(cn)).innerHTML = playerTotal;

        calculatePodium("gyn");
    }
}

// TO DO
//   - GYN Teams
//   - GYN totals (make 1st-3rd place identifiers)

// GYN Teams (color field)
var gynTeams = false;
function gynTeamsOnOff() {
    var colorfields = document.getElementsByClassName("gyn-color-fields");
    var label = document.getElementById("gyn-teams");
    var checkbox = document.getElementById("gyn-teams-cb");
    if (numColumns%2 == 0) {
        if (gynTeams == true) {
            gynTeams = false;
            for (var m = 0; m < colorfields.length; m++) {
                colorfields[m].style.display = "none";
            }
        } else {
            gynTeams = true;
            for (var m = 0; m < colorfields.length; m++) {
                colorfields[m].style.display = "block";
            }
        }
    } else {
        label.style.opacity = "0.5";
        checkbox.disabled = "disabled";
    }
}

// ************** FIVE CROWNS ***********************************************************************
var numFCPlayers;
// Create FC score table
function createFCTable() {
    numFCPlayers = parseInt(document.getElementById("fc-numplayers").value);
    numRows = 13;
    var fctable = document.getElementById("fc-scoretable");
    fctable.className = "scoretable";
    var errorMessage = document.getElementById("em-fctable");

    if (numFCPlayers>0 && numRows>1) {
        fctable.style.display = "block";
        fctable.style.maxHeight = String((52*numRows)+2).concat("px");
        errorMessage.style.display = "none";

        // Deletes all prexisting rows
        fctable.innerHTML = "";

        // Determines width of columns
        var tableWidth = window.innerWidth - 30;
        var otherColumnsWidth = tableWidth - 100 - (0*numFCPlayers);
        //var colwidth = String(otherColumnsWidth/numColumns).concat("px");
        var colwidth = String(100/numFCPlayers).concat("%");
        var otherColumnsWidth = String(otherColumnsWidth).concat("px");

        // Creates first column
        var currentColumn = document.createElement("SECTION");
        currentColumn.className = "st-firstcolumn";
        for (var rn = 0; rn < numRows; rn++) {
            var currentCell = document.createElement("SECTION");
            currentCell.className = "st-cell";

            if (rn == 0) { // FIRST ROW only
                currentCell.className = "st-cell st-firstrow";
                currentCell.innerHTML = "Round";
            } else if (rn == (numRows-1)) { // LAST ROW only
                currentCell.className = "st-cell st-lastrow";
                currentCell.innerHTML = "Total";
            } else { // OTHER ROWS (round numbers)
                switch (rn+2) {
                    case 11: currentCell.innerHTML = "J"; break;
                    case 12: currentCell.innerHTML = "Q"; break;
                    case 13: currentCell.innerHTML = "K"; break;
                    default: currentCell.innerHTML = rn+2; break;
                }
            }
            // IMPORTANT: Adds cell to end of column
            currentColumn.appendChild(currentCell);
        }
        fctable.appendChild(currentColumn);


        // Creates other columns/rows
        var otherColumns = document.createElement("SECTION");
        otherColumns.className = "st-othercolumns";
        otherColumns.style.width = otherColumnsWidth;

        for (var rn = 0; rn < numRows; rn++) {
            // Creates a row, gives it class st-row
            var currentRow = document.createElement("SECTION");
            currentRow.className = "st-row";

            // Creates row content
            if (rn == 0) {                    // FIRST ROW only
                for (var cn = 1; cn <= numFCPlayers; cn++) {
                    var currentCell = document.createElement("SECTION");
                    currentCell.className = "st-cell st-firstrow";
                    currentCell.style.width = colwidth;

                    if (cn == numFCPlayers) {
                        currentCell.className = "st-cell st-firstrow st-lastcolumn";
                    }

                    currentCell.innerHTML = "<input class='st-playername' type='text' placeholder='Player ".concat(cn,"'>");

                    // IMPORTANT: Adds cell to end of row
                    currentRow.appendChild(currentCell);
                }
            } else if (rn == (numRows-1)) {   // LAST ROW only
                for (var cn = 1; cn <= numFCPlayers; cn++) {
                    var currentCell = document.createElement("SECTION");
                    currentCell.className = "st-cell st-lastrow fc-playertotal";
                    currentCell.style.width = colwidth;

                    currentCell.id = "fc-pt-".concat(cn);

                    if (cn == numFCPlayers) {
                        currentCell.className = "st-cell st-lastrow fc-playertotal st-lastcolumn";}

                    // IMPORTANT: Adds cell to end of row
                    currentRow.appendChild(currentCell);
                }
            } else {                          // Other rows (round rows)
                for (var cn = 1; cn <= numFCPlayers; cn++) {
                    var currentCell = document.createElement("SECTION");
                    currentCell.className = "st-cell";
                    currentCell.style.width = colwidth;

                    // Dealer Cell
                    if (cn-1==(rn-1)%numFCPlayers) {
                        currentCell.className = "st-cell st-dealercell";
                    }
                    currentCell.innerHTML = "<input class='st-scorein fc-round".concat(rn," fc-player",cn,"' type='text' placeholder='0' id='fc-cell-p",cn,"r",rn,"' onchange='calculateFCPlayerTotals()'>");

                    // IMPORTANT: Adds cell to end of column
                    currentRow.appendChild(currentCell);
                }

                // NEXT STEPS: Add player columns. TO-DO:
                //    - Add editable player names
                //    - Add total row
                //    - Maybe: checkbox for team scores?
                //    - Highlight dealer cells
                // FOR PLAYER SUMS/SCORE ENTRIES - make an input box in each entry spot with class such as "score-p1" (using cn) and use fancy "getElementsByClassName" to add up the sum of all the inputs. Use calculate function as basis

                //    - FIX COLUMN WIDTH!!! otherColumnsWidth

            }
            // IMPORTANT: Adds column to scoretable
            otherColumns.appendChild(currentRow);
        }
        fctable.appendChild(otherColumns);
        calculateFCPlayerTotals();

    } else {
        fctable.style.display = "none";
        errorMessage.style.display = "block";
    }
}

// Calculate FC player totals
function calculateFCPlayerTotals() {
    for (var cn = 1; cn < (numFCPlayers+1); cn++) {
        var playerRoundTotals = document.getElementsByClassName("fc-player".concat(cn));
        var playerTotal = 0;
        for (var m = 0; m < playerRoundTotals.length; m++) {
            if (playerRoundTotals[m].value != 0) {playerTotal = playerTotal + parseInt(playerRoundTotals[m].value);}
        }
        document.getElementById("fc-pt-".concat(cn)).innerHTML = playerTotal;

        calculatePodium("fc");
    }
}

// ************************* Create 1st-3rd place markers ***********************************
function calculatePodium(game) {
    switch (game) {
        case "gyn": var playerRawTotals = document.getElementsByClassName('gyn-playertotal'); break;
        case "fc": var playerRawTotals = document.getElementsByClassName('fc-playertotal'); break;
    }
    var playerTotals = [0];
    var playerTotalsUnsorted = [0];
    for (var m = 0; m < numFCPlayers; m++) { // Gets actual player totals
        playerTotals = playerTotals.concat(parseInt(playerRawTotals[m].innerHTML)); // concatenates to end of array?????
        playerTotalsUnsorted = playerTotalsUnsorted.concat(parseInt(playerRawTotals[m].innerHTML)); // concatenates to end of array?????
        playerRawTotals[m].style.backgroundColor = '#222';
    }
    playerTotals.sort(function(a, b){return a - b}); // Compare function (https://www.w3schools.com/js/js_array_sort.asp)

    // Determine 2nd place threshold
    threshold2nd = 2;
    for (var i = 2; i < playerTotals.length; i++) {
        if (playerTotals[1] < playerTotals[i]) {
            threshold2nd = i;
            break;
        }
    }
    // Determine 3rd place threshold
    threshold3rd = 3;
    for (var i = threshold2nd; i < playerTotals.length; i++) {
        if (playerTotals[threshold2nd] < playerTotals[i]) {
            threshold3rd = i;
            break;
        }
    }

    // Assigns colors to 1st-3rd place cells
    for (var n = 0; n < numGYNPlayers; n++) {
        if (playerTotals[threshold3rd] == playerTotalsUnsorted[n+1]) { // Third place
            playerRawTotals[n].style.backgroundColor = '#9d5700';
        }
        if (playerTotals[threshold2nd] == playerTotalsUnsorted[n+1]) { // Second place
            playerRawTotals[n].style.backgroundColor = '#999';
        }
        if (playerTotals[1] == playerTotalsUnsorted[n+1]) { // First place
            playerRawTotals[n].style.backgroundColor = '#caa800';
        }
    }
    //document.getElementById('testdiv').innerHTML = String(playerRawTotals).concat("<br>",playerTotalsUnsorted,"<br>",playerTotals);
}
