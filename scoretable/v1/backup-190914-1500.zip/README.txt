// Backup created September 16 19, 3:00 PM
// Version unnamed

Features
    - Scoretables for the following games:
        - Get Your Neighbor
        - Five Crowns
    - Settings for number of players and rounds as necessary
    - Individual player totals
    - Dealer cell markers
    - Highlights 1st-3rd place players

To-Do
    - Merge all scoretable functions into one (one screen)
    - New games (i.e. new "presets" for creating table)
        - Hearts
        - Spades
        - Solitaire Tournament
    - Teams (GYN, Hearts, Spades) w/ color choice
    - Statistics? below scoretable
    - Clear scores
