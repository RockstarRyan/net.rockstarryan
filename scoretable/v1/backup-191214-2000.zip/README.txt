// Latest revision: December 5, 7:00 AM
// Version: unnamed

Features
    - Scoretables for the following games:
        - Get Your Neighbor
        - Five Crowns
		– Incrementor
    - Settings for number of players and rounds as necessary
    - Individual player totals
    - Dealer cell markers
    - Highlights 1st-3rd place players & organizes leaderboard for all players

To-Do
    - New games (i.e. new "presets" for creating table)
        - Hearts
        - Spades
        √ Solitaire Tournament
    - Teams (GYN, Hearts, Spades)
        - color choice
        - Create & show/hide team table at bottom
    - Other statistics below scoretable??
    - Clear just scores, not names
    - Zero-counter setting (GYN, FC)
    √ width - 200px or 300px?

	x appendScoretable() -> add or delete rows (new row amount - prev. row amount)
	* Better: restoreScoretable()
		- Change createScoretable() to create an array of all scores
		- "restore" as many as possible using for loop
	- On each game screen, add "+ New" button or "Use existing: <input>"
	√ Fix "high" scoring

	- NOTE: height does not adjust for two-line h2 in small spaces
