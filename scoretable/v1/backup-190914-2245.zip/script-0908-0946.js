// Calculate the sum of two numbers
function calculate() {
    var in1 = parseInt(document.getElementById('number1').value);
    var in2 = parseInt(document.getElementById('number2').value);
    var output = document.getElementById('result');

    output.innerHTML = in1 + in2;
}
// calculate();

// Nav buttons & hide/show screens on page load
document.getElementById('nb-home').style.color = "#07a";

function changeScreen(screenName, buttonName) {
    // Hide all screens
    var screens = document.getElementsByClassName('screen');
    for (var i = 0; i < screens.length; i++) {
        screens[i].style.display = 'none';
    }
    // Show corresponding screen
    document.getElementById(screenName).style.display = "block";

    // Show certain scoretables on game screens
    if (screenName == "gyn-screen") {
        createGYNTable();
    }

    // Make all buttons the default color
    var buttons = document.getElementsByClassName('nav-button');
    for (var j = 0; j < buttons.length; j++) {
        buttons[j].style.color = '#09e';
    }
    // Add special color to active "link"
    document.getElementById(buttonName).style.color = "#07a";
}

// Create score tables
function createGYNTable() {
    var numColumns = parseInt(document.getElementById("num-players").value) + 1;
    var numRows = parseInt(document.getElementById("num-rounds").value) + 2;
    var gyntable = document.getElementById("gyn-scoretable");
    var errorMessage = document.getElementById("em-gyntable");

    if (numColumns>1 && numRows>1) {
        gyntable.style.display = "block";
        gyntable.style.maxHeight = String(50*numRows).concat("px");
        errorMessage.style.display = "none";

        // Deletes all prexisting rows
        gyntable.innerHTML = "";

        // Creates sections (columns)
        var colwidth = String(100/numColumns).concat("%");
        colwidth = "calc(".concat(colwidth," - ",String((numColumns-3)/numColumns),"px)"); // ??? (why 3?)
        for (var cn = 0; cn < numColumns; cn++) {
            // Creates a column, gives it class gyn-column, and sets it to an equal width
            var currentColumn = document.createElement("SECTION");
            currentColumn.className = "gyn-column";
            currentColumn.style.width = colwidth;

            // C1 only
            if (cn == 0) {
                currentColumn.id = "gyn-firstcolumn";
                for (var rn = 0; rn < numRows; rn++) {
                    var currentCell = document.createElement("SECTION");
                    currentCell.className = "gyn-cell";

                    // Gives special id and class to C1-R1
                    if (rn == 0) {
                        currentCell.className = "gyn-cell gyn-firstrow";
                        currentCell.id = "gyn-firstcell";
                        currentCell.innerHTML = "Round";
                    } else if (rn == (numRows-1)) { // Total Row
                        currentCell.className = "gyn-cell gyn-lastrow";
                        currentCell.id = "gyn-lastcell";
                        currentCell.innerHTML = "Total";
                    } else { // Other rows (round rows)
                        currentCell.innerHTML = rn;
                    }
                    // IMPORTANT: Adds cell to end of column
                    currentColumn.appendChild(currentCell);
                }
            } else { // Other columns (player columns)
                for (var rn = 0; rn < numRows; rn++) {
                    var currentCell = document.createElement("SECTION");
                    currentCell.className = "gyn-cell";
                    currentCell.contentEditable = "true";

                    // Gives special id and class to C?-R1 (where C? represents any column except first)
                    if (rn == 0) {
                        currentCell.className = "gyn-cell gyn-firstrow";
                        currentCell.innerHTML = "Player".concat(cn);
                    } else {
                        currentCell.innerHTML = rn;
                    }
                    // IMPORTANT: Adds cell to end of column
                    currentColumn.appendChild(currentCell);
                }

                // NEXT STEPS: Add player columns. TO-DO:
                //    - Add editable player names
                //    - Add total row
                //    - Maybe: checkbox for team scores?
                //    - Highlight dealer cells

            }
            // IMPORTANT: Adds column to scoretable
            gyntable.appendChild(currentColumn);
        }

    } else {
        gyntable.style.display = "none";
        errorMessage.style.display = "block";
    }
    //gyntable.innerHTML = "<tr><td>Hi</td><tr>";
}
