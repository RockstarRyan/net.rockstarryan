// Calculate the sum of two numbers
function calculate() {
    var in1 = parseInt(document.getElementById('number1').value);
    var in2 = parseInt(document.getElementById('number2').value);
    var output = document.getElementById('result');

    output.innerHTML = in1 + in2;
}
// calculate();

// Nav buttons & hide/show screens on page load
document.getElementById('nb-home').style.color = "#07a";

function changeScreen(screenName, buttonName) {
    // Hide all screens
    var screens = document.getElementsByClassName('screen');
    for (var i = 0; i < screens.length; i++) {
        screens[i].style.display = 'none';
    }
    // Show corresponding screen
    document.getElementById(screenName).style.display = "block";

    // Show certain scoretables on game screens
    if (screenName == "gyn-screen") {
        createGYNTable();
    }

    // Make all buttons the default color
    var buttons = document.getElementsByClassName('nav-button');
    for (var j = 0; j < buttons.length; j++) {
        buttons[j].style.color = '#09e';
    }
    // Add special color to active "link"
    document.getElementById(buttonName).style.color = "#07a";
}

// Create score tables
function createGYNTable() {
    var numColumns = parseInt(document.getElementById("num-players").value) + 1;
    var numRows = parseInt(document.getElementById("num-rounds").value) + 2;
    var gyntable = document.getElementById("gyn-scoretable");
    var errorMessage = document.getElementById("em-gyntable");

    if (numColumns>1 && numRows>1) {
        gyntable.style.display = "block";
        gyntable.style.maxHeight = String((52*numRows)+2).concat("px");
        errorMessage.style.display = "none";

        // Deletes all prexisting rows
        gyntable.innerHTML = "";

        // Creates sections (rows)
        var colwidth = String(100/numColumns).concat("%");
        colwidth = "calc(".concat(colwidth," - ",String((numColumns-120)/numColumns),"px)"); // not sure why 120, but it works

        for (var rn = 0; rn < numRows; rn++) {
            // Creates a row, gives it class gyn-row
            var currentRow = document.createElement("SECTION");
            currentRow.className = "gyn-row";
            //currentRow.style.width = colwidth;

            // Creates row content
            if (rn == 0) { // FIRST ROW only
                currentRow.id = "gyn-firstrow";
                for (var cn = 0; cn < numColumns; cn++) {
                    var currentCell = document.createElement("SECTION");
                    currentCell.className = "gyn-cell gyn-firstrow";
                    currentCell.style.width = colwidth;

                    // Gives special id and class to R1-C1
                    if (cn == 0) {
                        currentCell.className = "gyn-cell gyn-firstrow gyn-firstcolumn";
                        currentCell.id = "gyn-cell-tl";
                        currentCell.innerHTML = "Round";
                    } else { // Other rows (round rows)
                        if (cn == (numColumns-1)) {
                            currentCell.className = "gyn-cell gyn-firstrow gyn-lastcolumn";
                            currentCell.id = "gyn-cell-tr";
                        }
                        currentCell.innerHTML = "<input class='gyn-playername' type='text' placeholder='Player ".concat(cn,"'>");
                    }
                    // IMPORTANT: Adds cell to end of row
                    currentRow.appendChild(currentCell);
                }
            } else if (rn == (numRows-1)) { // LAST ROW only
                currentRow.id = "gyn-lastrow";
                for (var cn = 0; cn < numColumns; cn++) {
                    var currentCell = document.createElement("SECTION");
                    currentCell.className = "gyn-cell gyn-lastrow";
                    currentCell.style.width = colwidth;

                    // Gives special id and class to C1
                    if (cn == 0) {
                        currentCell.className = "gyn-cell gyn-lastrow gyn-firstcolumn";
                        currentCell.id = "gyn-cell-bl";
                        currentCell.innerHTML = "Total";
                    } else { // Other rows (round rows)
                        if (cn == (numColumns-1)) {
                            currentCell.className = "gyn-cell gyn-lastrow gyn-lastcolumn";
                            currentCell.id = "gyn-cell-br";
                        }
                        currentCell.innerHTML = "Player".concat(cn);
                    }
                    // IMPORTANT: Adds cell to end of row
                    currentRow.appendChild(currentCell);
                }
            } else { // Other rows (round rows)
                for (var cn = 0; cn < numColumns; cn++) {
                    var currentCell = document.createElement("SECTION");
                    currentCell.className = "gyn-cell";
                    currentCell.style.width = colwidth;

                    // Gives special id and class to R1-C? (where C? represents any column except first)
                    if (cn == 0) {
                        currentCell.className = "gyn-cell gyn-firstcolumn";
                        currentCell.innerHTML = rn;
                    } else {
                        if (cn == (numColumns-1)) {currentCell.className = "gyn-cell gyn-lastcolumn";}

                        // Dealer Cell
                        if (numColumns>rn && cn==(rn%numColumns)) {
                            currentCell.className = "gyn-cell gyn-dealercell";
                        } else if (numColumns<(rn+1) && (numColumns*2)>(rn+1) && cn-1==((rn-numColumns)%numColumns)) {
                            currentCell.className = "gyn-cell gyn-dealercell";
                        } else if (numColumns<(rn+1) && (numColumns*2)>(rn+1) && cn-1==((rn-numColumns)%numColumns)) {
                            currentCell.className = "gyn-cell gyn-dealercell";
                        }
                        currentCell.innerHTML = "<input class='gyn-scorein gyn-round".concat(rn," gyn-player",cn,"' type='text' placeholder='0'>");
                    }
                    // IMPORTANT: Adds cell to end of column
                    currentRow.appendChild(currentCell);
                }

                // NEXT STEPS: Add player columns. TO-DO:
                //    - Add editable player names
                //    - Add total row
                //    - Maybe: checkbox for team scores?
                //    - Highlight dealer cells
                // FOR PLAYER SUMS/SCORE ENTRIES - make an input box in each entry spot with class such as "score-p1" (using cn) and use fancy "getElementsByClassName" to add up the sum of all the inputs. Use calculate function as basis

            }
            // IMPORTANT: Adds column to scoretable
            gyntable.appendChild(currentRow);
        }

    } else {
        gyntable.style.display = "none";
        errorMessage.style.display = "block";
    }
    //gyntable.innerHTML = "<tr><td>Hi</td><tr>";
}
