// Calculate the sum of two numbers
function calculate() {
    var in1 = parseInt(document.getElementById('number1').value);
    var in2 = parseInt(document.getElementById('number2').value);
    var output = document.getElementById('result');

    output.innerHTML = in1 + in2;
}
// calculate();

// Nav buttons & hide/show screens on page load
document.getElementById('nb-home').style.color = "#07a";

function changeScreen(screenName, buttonName) {
    // Hide all screens
    var screens = document.getElementsByClassName('screen');
    for (var i = 0; i < screens.length; i++) {
        screens[i].style.display = 'none';
    }
    // Show corresponding screen
    document.getElementById(screenName).style.display = "block";

    // Show certain scoretables on game screens
    if (screenName == "gyn-screen") {
        createGYNTable();
    }

    // Make all buttons the default color
    var buttons = document.getElementsByClassName('nav-button');
    for (var j = 0; j < buttons.length; j++) {
        buttons[j].style.color = '#09e';
    }
    // Add special color to active "link"
    document.getElementById(buttonName).style.color = "#07a";
}

// Create score tables
function createGYNTable() {
    var numColumns = parseInt(document.getElementById("num-players").value) + 1;
    var numRows = parseInt(document.getElementById("num-rounds").value) + 1;
    var gyntable = document.getElementById("gyn-scoretable");
    var errorMessage = document.getElementById("em-gyntable");

    if (numColumns>1 && numRows>1) {
        gyntable.style.display = "block";
        errorMessage.style.display = "none";

        // Deletes all prexisting rows
        gyntable.innerHTML = "";

        // Configures new column sizing (based on amount of columns)
        var cells = document.getElementsByTagName("TD");
        var cellwidth = String(100/numColumns).concat("%");
        for (var m = 0; m < cells.length; m++) {
            cells[m].style.width = cellwidth;
        }

        // Creates players row (<tr>)
        var gyntableplayerrow = gyntable.insertRow(-1);
        var tempcell = gyntableplayerrow.insertCell(-1);
        tempcell.innerHTML = "Round";
        tempcell.className = "player-row"
        for (var l = 1; l < numColumns; l++) {
            var tempcell = gyntableplayerrow.insertCell(-1);
            tempcell.innerHTML = "Player".concat(l);
            tempcell.contentEditable = "true";
            tempcell.className = "player-row";
        }

    } else {
        gyntable.style.display = "none";
        errorMessage.style.display = "block";
    }
    //gyntable.innerHTML = "<tr><td>Hi</td><tr>";
}
