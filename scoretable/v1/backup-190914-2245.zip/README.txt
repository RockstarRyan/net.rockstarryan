// Backup created September 14 19, 10:45 PM
// Version unnamed

Features:
    - Scoretables for the following games:
        - Get Your Neighbor
        - Five Crowns
    - Settings for number of players and rounds as necessary
    - Individual player totals
    - Dealer cell markers

To-Do
    - New games
        - Hearts
        - Spades
        - Solitaire Tournament
    - Teams (GYN, Hearts, Spades) w/ color choice
    - Statistics? below scoretable
    - Increase font size of player totals
    - Highlight 1st-3rd place players
